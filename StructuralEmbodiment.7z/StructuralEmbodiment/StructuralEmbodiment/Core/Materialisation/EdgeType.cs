﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuralEmbodiment.Core.Materialisation
{
    public enum EdgeType
    {
        TrailEdge,
        DeviationEdge
    }
}
